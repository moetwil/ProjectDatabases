# Someren starting project for InHolland project 'Databases'

Assignment2
Amber: B, UI Styling
Ethem: A
Luc: C, Logger

