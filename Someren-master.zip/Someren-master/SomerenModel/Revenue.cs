﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SomerenModel
{
    public class Revenue
    {
        public int DrinksSold { get; set; }
        public decimal TurnOver { get; set; }
        public int NumberOfCustomers { get; set; }
    }
}
